﻿namespace RunGroopWebApp.Helpers
{
    public class Location
    {
        public string? City { get; set; }
        public string? State { get; set; }
    }
}
