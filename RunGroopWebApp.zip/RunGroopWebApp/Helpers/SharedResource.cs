﻿namespace RunGroopWebApp.Helpers
{
    public class SharedResource
    {

    }
}
