﻿using RunGroopWebApp.Models;

namespace RunGroopWebApp.ViewModels
{
    public class RunningClubByCity
    {
        public List<City> Cities { get; set; } = new List<City>(); // ✅ Добавлено
    }
}
