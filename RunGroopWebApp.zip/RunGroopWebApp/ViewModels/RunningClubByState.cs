﻿using RunGroopWebApp.Models;

namespace RunGroopWebApp.ViewModels
{
    public class RunningClubByState
    {
        public List<State> States { get; set; } = new List<State>(); 
    }
}
