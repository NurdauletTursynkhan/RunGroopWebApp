﻿namespace RunGroopWebApp.Models
{
    public class State
    {
        public int Id { get; set; }
        public string StateName { get; set; } = string.Empty;
        public string StateCode { get; set; } = string.Empty;
    }
}
